import {Link,useParams} from 'react-router-dom';import {api,MARKET_NAMES} from '../api';import {bestListing,money,toUsd,useAsync} from '../lib';import {useApp} from '../ctx';import {Async,DemoBanner,ProductCard} from '../components/ui';
export function ProductPage(){const {slug=''}=useParams();const {favs,cmp,toggleFav,toggleCmp,rates,toast}=useApp();
 const s=useAsync(async()=>{const [p,l,h]=await Promise.all([api.product(slug),api.listings(slug),api.history(slug)]);const sim=await api.products({category:p.item.category,pageSize:5});return {p:p.item,l:l.items,h,sim:sim.items.filter(x=>x.id!==p.item.id)}},[slug]);
 return <><DemoBanner/><Link to="/search">← Back</Link><Async s={s}>{({p,l,h,sim})=>{const b=bestListing(l,rates);return <>
 <h1 style={{fontSize:'1.8rem',marginTop:'.5rem'}}>{p.name}</h1><p className="muted">{p.brand} · {p.category} · {p.storage} · {p.condition}</p>
 <div className="row nogrow" style={{marginBottom:'1rem'}}><button className={favs.includes(p.id)?'on-fav':''} onClick={()=>toggleFav(p.id)}>{favs.includes(p.id)?'Saved':'Save to favorites'}</button>
 <button onClick={()=>toggleCmp(p.slug)}>{cmp.includes(p.slug)?'Remove from comparison':'Add to comparison'}</button>
 <button onClick={()=>navigator.clipboard?.writeText(location.href).then(()=>toast('Link copied'),()=>toast('Copy not supported here'))}>Copy link</button><Link className="btn" to="/alerts">Set price alert</Link></div>
 <div className="grid"><div className="card"><h2>Specifications</h2><table style={{minWidth:0}}><tbody>{Object.entries(p.specifications).map(([k,v])=><tr key={k}><th>{k}</th><td>{v}</td></tr>)}<tr><th>Variant</th><td>{p.storage}, {p.condition}</td></tr></tbody></table></div>
 <div className="card"><h2>Price history</h2><p className="muted">{h.items.length?`${h.items.length} recorded data points.`:(h.note??'No historical price data is available.')}</p></div></div>
 <h2 style={{marginTop:'1.2rem'}}>Retailer listings</h2><div className="card scroll">{l.length?<table><thead><tr><th>Retailer</th><th>Market</th><th>Advertised price</th><th>Source</th><th>Last verified</th></tr></thead><tbody>{l.map(x=><tr key={x.id}><td>{x.productUrl?<a href={x.productUrl} rel="noopener noreferrer">{x.retailerName}</a>:x.retailerName}</td><td>{MARKET_NAMES[x.marketCode]}</td>
 <td className={x===b?'best':''}>{money(x.advertisedPriceMinor,x.currencyCode)}</td><td><span className="tag">{x.sourceType==='demo'?'Demo':x.sourceType}</span></td><td className="muted">{x.lastVerifiedAt??'Not verified'}</td></tr>)}</tbody></table>:<p className="muted">No listings.</p>}</div>
 <p className="muted">Advertised prices exclude shipping, taxes and import charges. Use the <Link to="/calculator">calculator</Link> for an estimate.</p>
 <h2>Similar products</h2>{sim.length?<div className="grid">{sim.map(x=><ProductCard key={x.id} p={x}/>)}</div>:<div className="muted">No similar products.</div>}</>}}</Async></>}
export function Compare(){const {cmp,toggleCmp,rates}=useApp();
 const s=useAsync(async()=>Promise.all(cmp.map(async sl=>{const [p,l]=await Promise.all([api.product(sl),api.listings(sl)]);return {...p.item,listings:l.items}})),[cmp.join(',')]);
 return <><h1 style={{fontSize:'1.6rem'}}>Compare</h1>{!cmp.length?<div className="card">Nothing to compare yet. Use “Compare” on a product card (up to 4).</div>:<><DemoBanner/><Async s={s}>{ps=>{
 const bs=ps.map(p=>bestListing(p.listings,rates)),us=bs.map(b=>b?toUsd(b.advertisedPriceMinor,b.currencyCode,rates):null),ok=us.every(u=>u!==null),lo=ok?Math.min(...(us as number[])):null;
 return <>{new Set(ps.map(p=>p.storage+p.condition)).size>1&&<div className="banner">These products differ in storage or condition, so prices are not like-for-like.</div>}
 {!ok&&<p className="muted">Prices in different currencies are not ranked until you enter manual exchange rates in the <Link to="/calculator">calculator</Link>.</p>}
 <div className="card scroll"><table><tbody><tr><th></th>{ps.map(p=><td key={p.id}><b><Link to={'/product/'+p.slug}>{p.name}</Link></b><br/><button onClick={()=>toggleCmp(p.slug)}>Remove</button></td>)}</tr>
 <tr><th>Brand</th>{ps.map(p=><td key={p.id}>{p.brand}</td>)}</tr><tr><th>Storage</th>{ps.map(p=><td key={p.id}>{p.storage}</td>)}</tr><tr><th>Condition</th>{ps.map(p=><td key={p.id}>{p.condition}</td>)}</tr>
 <tr><th>Advertised price</th>{bs.map((b,i)=><td key={ps[i].id} className={ok&&us[i]===lo?'best':''}>{b?<>{money(b.advertisedPriceMinor,b.currencyCode)}<br/><span className="muted">{MARKET_NAMES[b.marketCode]}</span></>:'No listing'}</td>)}</tr>
 <tr><th>Shipping / taxes</th>{ps.map(p=><td key={p.id} className="muted">Not estimated. Use the calculator.</td>)}</tr></tbody></table></div></>}}</Async></>}</>}

import {useEffect,useState} from 'react';import type {KeyboardEvent} from 'react';import {Link,useNavigate,useSearchParams} from 'react-router-dom';import {api,MARKET_NAMES} from '../api';import type {Product} from '../api';import {useAsync} from '../lib';import {Async,DemoBanner,ProductCard} from '../components/ui';
export function Home(){const nav=useNavigate();const [q,setQ]=useState('');const [sug,setSug]=useState<Product[]>([]);const [hl,setHl]=useState(-1);
 useEffect(()=>{if(!q.trim()){setSug([]);return}const t=setTimeout(()=>{api.products({q,pageSize:5}).then(r=>setSug(r.items),()=>setSug([]))},200);return()=>clearTimeout(t)},[q]);
 const trend=useAsync(()=>api.products({pageSize:4}),[]),cats=useAsync(()=>api.categories(),[]);
 const key=(e:KeyboardEvent)=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();if(sug.length)setHl((hl+(e.key==='ArrowDown'?1:-1)+sug.length)%sug.length)}else if(e.key==='Enter'&&hl>-1){e.preventDefault();nav('/product/'+sug[hl].slug)}};
 return <><DemoBanner/><section className="hero"><h1>Find the Best Price. Anywhere.</h1><p className="muted" style={{maxWidth:560}}>Compare electronics prices across international markets, estimate your total purchase cost, and make smarter shopping decisions.</p>
 <form className="sug" role="search" onSubmit={e=>{e.preventDefault();nav('/search?q='+encodeURIComponent(q))}}><label htmlFor="q" className="muted">Search products</label>
 <div className="row"><input id="q" value={q} autoComplete="off" placeholder="Search iPhone, Samsung, MacBook…" onChange={e=>{setQ(e.target.value);setHl(-1)}} onKeyDown={key} aria-controls="sl"/><button className="pri" style={{flex:'0 0 auto'}}>Search</button></div>
 {sug.length>0&&<ul id="sl">{sug.map((p,i)=><li key={p.id}><Link className={i===hl?'hl':''} to={'/product/'+p.slug}>{p.name} <span className="muted">{p.brand}</span></Link></li>)}</ul>}</form></section>
 <h2>Popular categories</h2><Async s={cats}>{c=><div className="row nogrow" style={{marginBottom:'1.5rem'}}>{c.items.map(x=><Link key={x} className="btn" to={'/search?category='+encodeURIComponent(x)}>{x}</Link>)}</div>}</Async>
 <h2>Trending</h2><Async s={trend}>{t=><div className="grid">{t.items.map(p=><ProductCard key={p.id} p={p}/>)}</div>}</Async></>}
export function Search(){const [sp,setSp]=useSearchParams();const g=(k:string)=>sp.get(k)??'';const [text,setText]=useState(g('q'));
 const set=(k:string,v:string)=>{const n=new URLSearchParams(sp);v?n.set(k,v):n.delete(k);setSp(n,{replace:true})};
 useEffect(()=>{const t=setTimeout(()=>{if(text!==g('q'))set('q',text)},300);return()=>clearTimeout(t)},[text]);// eslint-disable-line react-hooks/exhaustive-deps
 const cats=useAsync(()=>api.categories(),[]),all=useAsync(()=>api.products({pageSize:50}),[]);
 const res=useAsync(()=>api.products({q:g('q'),category:g('category'),brand:g('brand'),market:g('market'),pageSize:50}),[g('q'),g('category'),g('brand'),g('market')]);
 const brands=[...new Set((all.data?.items??[]).map(p=>p.brand))].sort();
 return <><DemoBanner/><h1 style={{fontSize:'1.6rem'}}>Search</h1><div className="card"><div className="row">
 <div><label htmlFor="fq">Query</label><input id="fq" value={text} onChange={e=>setText(e.target.value)}/></div>
 <div><label htmlFor="fc">Category</label><select id="fc" value={g('category')} onChange={e=>set('category',e.target.value)}><option value="">All categories</option>{cats.data?.items.map(c=><option key={c}>{c}</option>)}</select></div>
 <div><label htmlFor="fb">Brand</label><select id="fb" value={g('brand')} onChange={e=>set('brand',e.target.value)}><option value="">All brands</option>{brands.map(b=><option key={b}>{b}</option>)}</select></div>
 <div><label htmlFor="fm">Market</label><select id="fm" value={g('market')} onChange={e=>set('market',e.target.value)}><option value="">All markets</option>{Object.entries(MARKET_NAMES).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></div>
 <button style={{flex:'0 0 auto'}} onClick={()=>{setText('');setSp({})}}>Clear filters</button></div></div>
 <Async s={res}>{r=><><p className="muted">{r.total} result{r.total===1?'':'s'}, sorted by name. Price sorting is hidden because prices in different currencies need manual exchange rates (see Calculator).</p>
 {r.items.length?<div className="grid">{r.items.map(p=><ProductCard key={p.id} p={p} market={g('market')||undefined}/>)}</div>:<div className="card">No products match these filters. Try clearing them.</div>}</>}</Async></>}

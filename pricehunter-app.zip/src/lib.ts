import {useEffect,useState} from 'react';import {ApiError} from './api';import type {Listing} from './api';
export type Rates=Record<'CNY'|'AED'|'TJS',string>;
export const money=(m:number,c:string)=>(m/100).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})+' '+c;
export const errMsg=(e:unknown)=>e instanceof ApiError||e instanceof Error?e.message:'Something went wrong.';
/** Display-only conversion with manually entered rates (units per 1 USD). Never authoritative. */
export const toUsd=(m:number,c:string,r:Rates)=>c==='USD'?m:parseFloat(r[c as keyof Rates])>0?m/parseFloat(r[c as keyof Rates]):null;
export function bestListing(l:Listing[],r:Rates,market?:string){const f=l.filter(x=>!market||x.marketCode===market);if(!f.length)return null;
 const u=f.map(x=>toUsd(x.advertisedPriceMinor,x.currencyCode,r));return u.every(x=>x!==null)?f[u.indexOf(Math.min(...(u as number[])))]:market?[...f].sort((a,b)=>a.advertisedPriceMinor-b.advertisedPriceMinor)[0]:f[0]}
export const ls=<T,>(k:string,d:T):T=>{try{const v=localStorage.getItem('ph_'+k);return v?JSON.parse(v):d}catch{return d}};
export const lsSet=(k:string,v:unknown)=>{try{localStorage.setItem('ph_'+k,JSON.stringify(v))}catch{/* storage unavailable */}};
export interface AsyncState<T>{data?:T;error?:string;loading:boolean;reload:()=>void}
export function useAsync<T>(fn:()=>Promise<T>,deps:unknown[]):AsyncState<T>{
 const [s,set]=useState<{data?:T;error?:string;loading:boolean}>({loading:true});const [n,setN]=useState(0);
 useEffect(()=>{let live=true;set(x=>({...x,loading:true,error:undefined}));fn().then(data=>live&&set({data,loading:false}),e=>live&&set({loading:false,error:errMsg(e)}));return()=>{live=false}},[...deps,n]);// eslint-disable-line react-hooks/exhaustive-deps
 return {...s,reload:()=>setN(x=>x+1)}}

import {createContext,useContext,useEffect,useState} from 'react';import type {ReactNode} from 'react';import {api} from './api';import {errMsg,ls,lsSet} from './lib';import type {Rates} from './lib';
interface Ctx{favs:string[];toggleFav:(id:string)=>Promise<void>;cmp:string[];toggleCmp:(slug:string)=>void;rates:Rates;setRate:(c:keyof Rates,v:string)=>void;demo:boolean|null;toast:(t:string)=>void;msg:string}
const C=createContext<Ctx>(null as unknown as Ctx);export const useApp=()=>useContext(C);
export function AppProvider({children}:{children:ReactNode}){
 const [favs,setFavs]=useState<string[]>([]);const [demo,setDemo]=useState<boolean|null>(null);const [msg,setMsg]=useState('');
 // Local-only (documented): comparison selection and manual display rates are not stored on the server.
 const [cmp,setCmp]=useState<string[]>(()=>ls('cmp',[]));const [rates,setRates]=useState<Rates>(()=>ls('rates',{CNY:'',AED:'',TJS:''}));
 const toast=(t:string)=>{setMsg(t);setTimeout(()=>setMsg(''),2400)};
 useEffect(()=>{api.favorites().then(r=>setFavs(r.items),e=>toast(errMsg(e)));api.health().then(h=>setDemo(h.dataMode==='demo'),()=>setDemo(null))},[]);
 const toggleFav=async(id:string)=>{try{if(favs.includes(id)){await api.removeFavorite(id);setFavs(f=>f.filter(x=>x!==id));toast('Removed from favorites')}else{await api.addFavorite(id);setFavs(f=>[...f,id]);toast('Saved to favorites')}}catch(e){toast(errMsg(e))}};
 const toggleCmp=(s:string)=>{if(!cmp.includes(s)&&cmp.length>=4)return toast('You can compare up to 4 products');const n=cmp.includes(s)?cmp.filter(x=>x!==s):[...cmp,s];setCmp(n);lsSet('cmp',n)};
 const setRate=(c:keyof Rates,v:string)=>{const n={...rates,[c]:v};setRates(n);lsSet('rates',n)};
 return <C.Provider value={{favs,toggleFav,cmp,toggleCmp,rates,setRate,demo,toast,msg}}>{children}</C.Provider>}

import {Link} from 'react-router-dom';import type {ReactNode} from 'react';import {useApp} from '../ctx';import {bestListing,money} from '../lib';import type {AsyncState} from '../lib';import type {Product} from '../api';import {MARKET_NAMES} from '../api';
export function DemoBanner(){const {demo}=useApp();return demo===false?null:<div className="banner"><span className="tag">DEMO DATA</span> Products, retailers and prices here are demonstration values for interface testing, not verified or live offers. No external retailer links exist.</div>}
export function Async<T>({s,children}:{s:AsyncState<T>;children:(d:T)=>ReactNode}){
 if(s.error)return <div className="card err" role="alert">{s.error} <button onClick={s.reload}>Retry</button></div>;
 if(s.data===undefined)return <div className="card" role="status">Loading…</div>;return <>{children(s.data)}</>}
export function ProductCard({p,market}:{p:Product;market?:string}){
 const {favs,cmp,toggleFav,toggleCmp,rates}=useApp();const b=bestListing(p.listings??[],rates,market);const f=favs.includes(p.id),c=cmp.includes(p.slug);
 return <div className="card"><div className="img" role="img" aria-label={p.name+' image placeholder'}>{p.category}</div>
 <h3><Link to={'/product/'+p.slug} style={{color:'inherit',textDecoration:'none'}}>{p.name}</Link></h3><div className="muted">{p.brand} · {p.storage} · {p.condition}</div>
 {b?<><div className="price">{money(b.advertisedPriceMinor,b.currencyCode)}</div><div className="muted">{MARKET_NAMES[b.marketCode]} · <span className="tag">{b.sourceType==='demo'?'Demo':b.sourceType}</span></div></>:<div className="muted">No listing in this market</div>}
 <div className="row" style={{marginTop:'.6rem'}}><button className={f?'on-fav':''} aria-pressed={f} onClick={()=>toggleFav(p.id)}>{f?'Saved':'Save'}</button><button onClick={()=>toggleCmp(p.slug)}>{c?'Remove':'Compare'}</button></div></div>}

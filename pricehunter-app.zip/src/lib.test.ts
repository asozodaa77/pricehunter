import {describe,it,expect} from 'vitest';import {bestListing,errMsg,money,toUsd} from './lib';import {ApiError,clientId} from './api';import type {Listing} from './api';
const L=(m:string,minor:number,c:string):Listing=>({id:m+minor,productId:'p',retailerName:'r',marketCode:m,advertisedPriceMinor:minor,currencyCode:c,sourceType:'demo',productUrl:null,lastVerifiedAt:null});
const none={CNY:'',AED:'',TJS:''};
describe('price helpers',()=>{
 it('formats minor units',()=>{expect(money(12345,'USD')).toMatch(/123[.,]45 USD$/)});
 it('converts only with a manual rate',()=>{expect(toUsd(100,'AED',none)).toBeNull();expect(toUsd(36725,'AED',{...none,AED:'3.6725'})).toBeCloseTo(10000);expect(toUsd(5,'USD',none)).toBe(5)});
 it('ranks across currencies only when rates exist',()=>{const l=[L('US',50000,'USD'),L('AE',150000,'AED')];
  expect(bestListing(l,{...none,AED:'3.6725'})?.marketCode).toBe('AE');expect(bestListing(l,none)?.marketCode).toBe('US')});
 it('picks the lowest listing within a market and handles none',()=>{const l=[L('US',900,'USD'),L('US',500,'USD'),L('CN',1,'CNY')];expect(bestListing(l,none,'US')?.advertisedPriceMinor).toBe(500);expect(bestListing(l,none,'TJ')).toBeNull()})});
describe('api client helpers',()=>{
 it('keeps a stable uuid-shaped client id',()=>{const a=clientId();expect(a).toMatch(/^[0-9a-f-]{36}$/);expect(clientId()).toBe(a)});
 it('builds readable error messages',()=>{expect(errMsg(new ApiError(400,{issues:[{path:'x',message:'bad'}]}))).toBe('bad');expect(errMsg('x')).toBe('Something went wrong.')})});

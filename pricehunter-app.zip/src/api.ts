export type Src='verified_live'|'imported'|'manual'|'demo'|'estimate';
export interface Listing{id:string;productId:string;retailerName:string;marketCode:string;advertisedPriceMinor:number;currencyCode:string;sourceType:Src;productUrl:string|null;lastVerifiedAt:string|null}
export interface Product{id:string;slug:string;name:string;brand:string;category:string;storage:string;condition:string;specifications:Record<string,string>;listings?:Listing[]}
export interface Alert{id:string;productId:string;market:string;currency:string;targetMinor:number;status:string;createdAt:string}
export interface Estimate{ok:true;rate:number;rateSource:string;originalMinor:number;convertedMinor:number;breakdownMinor:Record<'shipping'|'insurance'|'customs'|'other',number>;totalMinor:number;from:string;to:string}
export interface MarketInfo{code:string;name:string;currency:string}
export interface EstimateInput{price:number;from:string;to:string;rate?:number;shipping:number;insurance:number;customs:number;other:number}
export const CURRENCIES=['USD','CNY','AED','TJS'];
export const MARKET_NAMES:Record<string,string>={CN:'China',US:'United States',AE:'United Arab Emirates',TJ:'Tajikistan'};
const BASE=(import.meta.env.VITE_API_BASE as string|undefined)??'';
let mem:string|undefined;
/** Anonymous identifier that scopes favorites/alerts. It is NOT authentication. */
export function clientId():string{try{let v=localStorage.getItem('ph_client_id');if(!v){v=crypto.randomUUID();localStorage.setItem('ph_client_id',v)}return v}catch{return mem??=crypto.randomUUID()}}
export class ApiError extends Error{constructor(public status:number,public body:{error?:string;message?:string;issues?:{path:string;message:string}[]}|null){super(body?.message??body?.issues?.map(i=>i.message).join('; ')??body?.error??'Request failed')}}
async function req<T>(path:string,init:RequestInit={}):Promise<T>{
 let r:Response;try{r=await fetch(BASE+'/api'+path,{...init,headers:{...(init.body?{'content-type':'application/json'}:{}),'x-client-id':clientId()}})}catch{throw new ApiError(0,{message:'Cannot reach the server. Check that the API is running.'})}
 if(r.status===204)return undefined as T;const b=await r.json().catch(()=>null);if(!r.ok)throw new ApiError(r.status,b);return b as T}
const qs=(o:Record<string,string|number|undefined>)=>{const p=new URLSearchParams();for(const [k,v] of Object.entries(o))if(v!==undefined&&v!=='')p.set(k,String(v));const s=p.toString();return s?'?'+s:''};
const body=(m:string,b:unknown):RequestInit=>({method:m,body:JSON.stringify(b)});
export const api={
 health:()=>req<{ok:boolean;dataMode:'demo'|'provider';provider:string}>('/health'),
 products:(q:{q?:string;category?:string;brand?:string;market?:string;page?:number;pageSize?:number}={})=>req<{items:Product[];total:number}>('/products'+qs(q)),
 product:(slug:string)=>req<{item:Product}>('/products/'+encodeURIComponent(slug)),
 listings:(slug:string)=>req<{items:Listing[]}>(`/products/${encodeURIComponent(slug)}/listings`),
 history:(slug:string)=>req<{items:unknown[];note?:string}>(`/products/${encodeURIComponent(slug)}/history`),
 markets:()=>req<{items:MarketInfo[]}>('/markets'),categories:()=>req<{items:string[]}>('/categories'),
 estimate:(b:EstimateInput)=>req<Estimate>('/calculator/estimate',body('POST',b)),
 favorites:()=>req<{items:string[]}>('/favorites'),addFavorite:(productId:string)=>req<{productId:string}>('/favorites',body('POST',{productId})),
 removeFavorite:(id:string)=>req<void>('/favorites/'+encodeURIComponent(id),{method:'DELETE'}),
 alerts:()=>req<{items:Alert[];note:string}>('/alerts'),
 createAlert:(b:{productId:string;market:string;currency:string;targetMinor:number})=>req<{item:Alert}>('/alerts',body('POST',b)),
 updateAlert:(id:string,b:{targetMinor?:number})=>req<{item:Alert}>('/alerts/'+id,body('PATCH',b)),
 deleteAlert:(id:string)=>req<void>('/alerts/'+id,{method:'DELETE'}),
 assistant:(message:string)=>req<{text:string;provider:string;isAi:boolean}>('/assistant',body('POST',{message}))};

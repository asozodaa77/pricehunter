import {Component,lazy,Suspense,useEffect} from 'react';import type {ComponentType,ReactNode} from 'react';import {NavLink,Route,Routes,useLocation} from 'react-router-dom';import {useApp} from './ctx';import {ls,lsSet} from './lib';import {Home} from './pages/Catalog';
const L=<T extends Record<string,ComponentType>>(f:()=>Promise<T>,k:keyof T)=>lazy(()=>f().then(m=>({default:m[k]})));
const Search=L(()=>import('./pages/Catalog'),'Search'),ProductPage=L(()=>import('./pages/Product'),'ProductPage'),Compare=L(()=>import('./pages/Product'),'Compare');
const Markets=L(()=>import('./pages/Tools'),'Markets'),Calculator=L(()=>import('./pages/Tools'),'Calculator'),About=L(()=>import('./pages/Tools'),'About'),Assistant=L(()=>import('./pages/Tools'),'Assistant');
const Favorites=L(()=>import('./pages/User'),'Favorites'),Alerts=L(()=>import('./pages/User'),'Alerts');
const links:[string,string][]=[['/','Home'],['/search','Search'],['/compare','Compare'],['/markets','Markets'],['/calculator','Calculator'],['/favorites','Favorites'],['/alerts','Alerts'],['/assistant','Assistant'],['/about','About']];
class Boundary extends Component<{children:ReactNode},{bad:boolean}>{state={bad:false};static getDerivedStateFromError(){return {bad:true}}render(){return this.state.bad?<div className="card err" role="alert">Something went wrong rendering this page. Reload to try again.</div>:this.props.children}}
export default function App(){const {cmp,favs,msg}=useApp();const loc=useLocation();
 useEffect(()=>{const t=ls<string|null>('theme',null);if(t)document.documentElement.dataset.theme=t},[]);useEffect(()=>window.scrollTo(0,0),[loc.pathname]);
 const flip=()=>{const r=document.documentElement,c=r.dataset.theme||(matchMedia('(prefers-color-scheme:light)').matches?'light':'dark'),n=c==='dark'?'light':'dark';r.dataset.theme=n;lsSet('theme',n)};
 return <><header><div className="bar"><NavLink className="logo" to="/">Price<b>Hunter</b></NavLink>
 <nav aria-label="Main">{links.map(([to,t])=><NavLink key={to} to={to} end={to==='/'} className={({isActive})=>isActive?'on':''}>{t}{to==='/compare'&&cmp.length?` (${cmp.length})`:''}{to==='/favorites'&&favs.length?` (${favs.length})`:''}</NavLink>)}</nav>
 <button onClick={flip} aria-label="Toggle light or dark theme">Theme</button></div></header>
 <main><Boundary><Suspense fallback={<div className="card" role="status">Loading…</div>}><Routes><Route path="/" element={<Home/>}/><Route path="/search" element={<Search/>}/><Route path="/product/:slug" element={<ProductPage/>}/><Route path="/compare" element={<Compare/>}/>
 <Route path="/markets" element={<Markets/>}/><Route path="/calculator" element={<Calculator/>}/><Route path="/favorites" element={<Favorites/>}/><Route path="/alerts" element={<Alerts/>}/><Route path="/assistant" element={<Assistant/>}/><Route path="/about" element={<About/>}/>
 <Route path="*" element={<div className="card">Page not found.</div>}/></Routes></Suspense></Boundary></main>
 {msg&&<div id="toast" role="status" style={{display:'block'}}>{msg}</div>}</>}

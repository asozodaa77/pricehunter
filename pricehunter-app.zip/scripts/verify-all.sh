#!/usr/bin/env bash
# Runs every verification step for real and prints an honest summary (also saved to verify-summary.txt).
# Usage: bash scripts/verify-all.sh        (needs network, Node 20+, Docker)
cd "$(dirname "$0")/.." || exit 1
R=()
step(){ local n="$1"; shift; echo; echo "=== $n ==="; if "$@"; then R+=("PASS  $n"); else R+=("FAIL  $n"); fi; }
up(){ docker compose up -d --build || return 1; for _ in $(seq 1 40); do curl -fsS http://localhost:8787/api/health >/dev/null 2>&1 && return 0; sleep 3; done; docker compose logs --tail=40 api; return 1; }
step "1 npm install (creates package-lock.json)" npm install
step "2 npm run verify (typecheck + tests + build)" npm run verify
step "3 docker compose up (Postgres + app)" up
step "4 database integration tests" env TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/pricehunter npm run test:db
step "5 API + frontend smoke test" bash scripts/smoke.sh
{ echo "=========== SUMMARY ==========="; printf '%s\n' "${R[@]}"; echo "Not covered by this script: browser/mobile checks (do those by hand)."; } | tee verify-summary.txt

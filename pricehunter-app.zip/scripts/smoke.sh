#!/usr/bin/env bash
# Black-box check of a RUNNING PriceHunter (API + built frontend). Usage: BASE_URL=http://localhost:8787 bash scripts/smoke.sh
BASE="${BASE_URL:-http://localhost:8787}"; A="11111111-1111-4111-8111-111111111111"; B="22222222-2222-4222-8222-222222222222"; fail=0
check(){ if [[ "$3" == *"$2"* ]]; then echo "PASS  $1"; else echo "FAIL  $1 (expected: $2) (got: ${3:0:160})"; fail=1; fi; }
J=(-H 'content-type: application/json')
check "health ok" '"ok":true' "$(curl -fsS "$BASE/api/health")"
check "data is labeled demo" '"dataMode":"demo"' "$(curl -fsS "$BASE/api/health")"
check "search + market filter" '"total":1' "$(curl -fsS "$BASE/api/products?q=iphone&market=CN")"
check "listings are labeled demo" '"sourceType":"demo"' "$(curl -fsS "$BASE/api/products/iphone-16-128/listings")"
check "price history is honestly empty" '"items":[]' "$(curl -fsS "$BASE/api/products/iphone-16-128/history")"
check "add favorite" 'iphone-16-128' "$(curl -fsS -H "x-client-id: $A" "${J[@]}" -d '{"productId":"iphone-16-128"}' "$BASE/api/favorites")"
check "favorite is stored" 'iphone-16-128' "$(curl -fsS -H "x-client-id: $A" "$BASE/api/favorites")"
check "other client sees none" '"items":[]' "$(curl -fsS -H "x-client-id: $B" "$BASE/api/favorites")"
check "alert saved, not monitored" 'saved_not_monitored' "$(curl -fsS -H "x-client-id: $A" "${J[@]}" -d '{"productId":"ipad-10-64","market":"US","currency":"USD","targetMinor":30000}' "$BASE/api/alerts")"
check "calculator estimate" '"totalMinor":36725' "$(curl -fsS "${J[@]}" -d '{"price":100,"from":"USD","to":"AED","rate":3.6725}' "$BASE/api/calculator/estimate")"
check "missing rate rejected" 'exchange_rate_required' "$(curl -sS "${J[@]}" -d '{"price":1,"from":"USD","to":"AED"}' "$BASE/api/calculator/estimate")"
check "bad input rejected" 'validation_error' "$(curl -sS "$BASE/api/products?market=XX")"
check "frontend is served" '<div id="root">' "$(curl -fsS "$BASE/")"
check "deep link falls back to the app" '<div id="root">' "$(curl -fsS "$BASE/product/iphone-16-128")"
[[ $fail == 0 ]] && echo "ALL SMOKE CHECKS PASSED" || echo "SOME SMOKE CHECKS FAILED"; exit $fail

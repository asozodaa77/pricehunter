# PriceHunter (v0.3.1)

Electronics price comparison for China, US, UAE and Tajikistan. React + Vite frontend (`src/`), Express + Zod API (`server/src/`), optional PostgreSQL.
All catalog data is **demonstration data** (placeholder prices, no retailer links). No live prices, exchange rates, price history, or notifications exist.

## Verification status (be honest about it)
Static code review only so far. **Never executed:** `npm install`, type check, vitest, the Vite build, the Express server, any SQL, the Docker files, CI, and the UI in a browser.
The only things run: an esbuild syntax parse of all TS/TSX files, and a dependency-free Node run of the calculator and demo provider.
Treat every claim below as unverified until `npm run verify` and the browser checklist pass on a machine with network access.

## Quickest path to verification
    npm install && npm run verify                   # typecheck + all non-DB tests + production build
    docker compose up --build                       # API + Postgres + built frontend on http://localhost:8787
    # then, with the compose db running: TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/pricehunter npm run test:db
Pushing to GitHub runs the same checks, including the Postgres tests, via `.github/workflows/ci.yml`.
Browser checklist: home search + suggestions, search filters, product page, compare (4 max), calculator, favorites/alerts surviving a reload, theme toggle, 375px-wide layout with no horizontal scroll.

## Run (needs network for `npm install`)
    npm install
    cp .env.example .env
    npm run typecheck        # fix any type errors first
    npm test                 # API, validation, calculator, frontend helper tests (DB tests are skipped without TEST_DATABASE_URL)
    npm run start            # API on :8787, demo fixtures + in-memory user data
    npm run dev              # Vite on :5173, proxies /api to :8787

## With PostgreSQL
    docker compose up -d db                      # or any Postgres 13+
    export DATABASE_URL=postgres://postgres:postgres@localhost:5432/pricehunter
    npm run db:setup                             # schema (once) + DEMO seed; idempotent, transactional
    TEST_DATABASE_URL=$DATABASE_URL npm run test:db   # integration tests; use a DISPOSABLE database
    npm run start
Or everything in containers: `docker compose up --build` (API on :8787, serves the built frontend).

## Architecture
- `server/src/providers/types.ts`: CatalogProvider, CurrencyProvider, AssistantProvider. Implementations: demo fixtures or Postgres (catalog), manual operator rates (currency), rule-based (assistant). Add a real provider by implementing an interface and wiring it in `server/src/index.ts`.
- `src/api.ts`: the only place the frontend talks to the API. Sends `x-client-id` (random UUID in localStorage). It scopes favorites/alerts, it is **not authentication**; anyone holding the ID can read that data. Add real auth before storing anything sensitive.
- Local-only by design: theme, comparison selection, manual display exchange rates.
- Lists are capped at 50 products per request (no pagination UI yet). Alerts are saved as `saved_not_monitored`: nothing monitors prices or sends notifications.

## Deployment (prepared, NOT deployed)
- Single container: `Dockerfile` builds the frontend and the API serves `dist/` plus `/api`. Set `DATABASE_URL`, `TRUST_PROXY` (usually 1), run `npx tsx server/db/setup.ts` once. Run `npm install` first and commit `package-lock.json`.
- Split hosting: static host for `dist/` (needs an SPA rewrite to `index.html`) plus a Node host for the API; set `VITE_API_BASE` at build time and `ALLOWED_ORIGIN` on the API.
- Hosted Postgres usually needs `?sslmode=require`. Never expose `DATABASE_URL` or `AI_API_KEY` to the frontend.
- Unreviewed for production: HTTPS/headers tuning, backups, logging, monitoring, and Postgres row-level security.

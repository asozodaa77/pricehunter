import {describe,it,expect} from 'vitest';import request from 'supertest';
import {estimate} from '../src/calc.ts';import {createApp} from '../src/app.ts';
import {DemoCatalogProvider} from '../src/providers/demo.ts';import {ManualCurrencyProvider} from '../src/providers/currency.ts';
import {RuleBasedAssistant} from '../src/providers/assistant.ts';import {MemoryStore} from '../src/store.ts';
const app=createApp({catalog:new DemoCatalogProvider(),currency:new ManualCurrencyProvider({},null),assistant:new RuleBasedAssistant(),store:new MemoryStore()});
const id='11111111-1111-4111-8111-111111111111';
describe('calculator',()=>{
 it('sums in minor units',()=>{const r=estimate({price:10.1,from:'USD',to:'USD',shipping:1.1,insurance:0,customs:2,other:0});expect(r.ok&&r.totalMinor).toBe(1320)});
 it('requires a rate across currencies',()=>{expect(estimate({price:1,from:'USD',to:'AED',shipping:0,insurance:0,customs:0,other:0}).ok).toBe(false)})});
describe('api',()=>{
 it('health reports demo mode',async()=>{const r=await request(app).get('/api/health');expect(r.body.dataMode).toBe('demo')});
 it('filters products',async()=>{const r=await request(app).get('/api/products?q=iphone&market=CN');expect(r.body.total).toBe(1)});
 it('rejects bad input',async()=>{expect((await request(app).get('/api/products?market=XX')).status).toBe(400)});
 it('history is honestly empty',async()=>{const r=await request(app).get('/api/products/iphone-16-128/history');expect(r.body.items).toEqual([])});
 it('missing rate is 404',async()=>{expect((await request(app).get('/api/rates?from=USD&to=CNY')).status).toBe(404)});
 it('favorites persist per client',async()=>{await request(app).post('/api/favorites').set('x-client-id',id).send({productId:'iphone-16-128'});
  expect((await request(app).get('/api/favorites').set('x-client-id',id)).body.items).toEqual(['iphone-16-128'])});
 it('requires client id',async()=>{expect((await request(app).get('/api/favorites')).status).toBe(400)})});

describe('isolation and integrity',()=>{
 const other='22222222-2222-4222-8222-222222222222';
 it('hides one client\'s alerts from another',async()=>{await request(app).post('/api/alerts').set('x-client-id',id).send({productId:'iphone-16-128',market:'US',currency:'USD',targetMinor:5000});
  expect((await request(app).get('/api/alerts').set('x-client-id',other)).body.items).toEqual([])});
 it('rejects alerts for unknown products',async()=>{expect((await request(app).post('/api/alerts').set('x-client-id',id).send({productId:'nope',market:'US',currency:'USD',targetMinor:5000})).status).toBe(404)});
 it('includes listings in product list',async()=>{const r=await request(app).get('/api/products?q=iphone');expect(r.body.items[0].listings.length).toBeGreaterThan(0)})});
describe('validation and errors',()=>{
 const post=(p:string,b:object)=>request(app).post(p).set('x-client-id',id).send(b);
 it('rejects negative amounts',async()=>{expect((await post('/api/calculator/estimate',{price:-1,from:'USD',to:'USD'})).status).toBe(400)});
 it('converts with a client-supplied rate and labels it an estimate',async()=>{const r=await post('/api/calculator/estimate',{price:100,from:'USD',to:'AED',rate:3.6725});expect(r.body.convertedMinor).toBe(36725);expect(r.body.isEstimate).toBe(true)});
 it('422 when a cross-currency rate is missing',async()=>{expect((await post('/api/calculator/estimate',{price:1,from:'USD',to:'CNY'})).status).toBe(422)});
 it('422 instead of overflow on absurd amounts',async()=>{expect((await post('/api/calculator/estimate',{price:1e9,from:'USD',to:'TJS',rate:1e6})).status).toBe(422)});
 it('rejects an empty alert patch',async()=>{const a=await post('/api/alerts',{productId:'ipad-10-64',market:'US',currency:'USD',targetMinor:100});
  expect((await request(app).patch('/api/alerts/'+a.body.item.id).set('x-client-id',id).send({})).status).toBe(400)});
 it('rejects a malformed client id',async()=>{expect((await request(app).get('/api/favorites').set('x-client-id','abc')).status).toBe(400)});
 it('removes a favorite',async()=>{const c='33333333-3333-4333-8333-333333333333';await request(app).post('/api/favorites').set('x-client-id',c).send({productId:'ipad-10-64'});
  expect((await request(app).delete('/api/favorites/ipad-10-64').set('x-client-id',c)).status).toBe(204);expect((await request(app).get('/api/favorites').set('x-client-id',c)).body.items).toEqual([])});
 it('returns JSON 404 for unknown api routes',async()=>{const r=await request(app).get('/api/nope');expect(r.status).toBe(404);expect(r.body.error).toBe('not_found')});
 it('rejects an empty assistant message and labels replies as non-AI',async()=>{expect((await post('/api/assistant',{message:'  '})).status).toBe(400);expect((await post('/api/assistant',{message:'iPhone 16'})).body.isAi).toBe(false)});
 it('does not leak internals on server errors',async()=>{const bad=createApp({catalog:Object.assign(new DemoCatalogProvider(),{search:async()=>{throw new Error('secret-db-password')}}),currency:new ManualCurrencyProvider({},null),assistant:new RuleBasedAssistant(),store:new MemoryStore()});
  const r=await request(bad).get('/api/products');expect(r.status).toBe(500);expect(JSON.stringify(r.body)).not.toContain('secret')})});

describe('body parsing',()=>{
 it('returns 400 for malformed JSON',async()=>{const r=await request(app).post('/api/assistant').set('content-type','application/json').send('{bad');expect(r.status).toBe(400);expect(r.body.error).toBe('invalid_json')});
 it('returns 413 for oversized bodies',async()=>{const r=await request(app).post('/api/assistant').send({message:'x'.repeat(30000)});expect(r.status).toBe(413)})});

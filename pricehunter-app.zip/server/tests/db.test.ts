// Integration tests: skipped unless TEST_DATABASE_URL points at a DISPOSABLE Postgres database.
import {describe,it,expect,beforeAll,afterAll} from 'vitest';import pg from 'pg';import type {Pool} from 'pg';
import {setupDatabase} from '../db/seed.ts';import {PgStore} from '../src/pgStore.ts';import {PgCatalogProvider} from '../src/providers/pg.ts';
const url=process.env.TEST_DATABASE_URL;const A='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',B='bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
describe.skipIf(!url)('postgres integration',()=>{
 let pool:Pool,store:PgStore,cat:PgCatalogProvider;
 beforeAll(async()=>{pool=new pg.Pool({connectionString:url});await setupDatabase(pool);store=new PgStore(pool);cat=new PgCatalogProvider(pool)});
 afterAll(async()=>{await pool?.query('delete from favorites where client_id in($1,$2)',[A,B]);await pool?.query('delete from price_alerts where client_id in($1,$2)',[A,B]);await pool?.end()});
 const counts=async()=>(await pool.query('select (select count(*)::int from products) p,(select count(*)::int from retailer_listings) l')).rows[0];
 it('seeding twice creates no duplicates',async()=>{const a=await counts();await setupDatabase(pool);expect(await counts()).toEqual(a)});
 it('searches, filters by market and labels listings as demo',async()=>{const r=await cat.search({q:'iphone',market:'CN',page:1,pageSize:10});expect(r.total).toBe(1);
  const l=await cat.listings(r.items[0].id);expect(l.length).toBeGreaterThan(0);expect(l.every(x=>x.sourceType==='demo')).toBe(true);expect(typeof l[0].advertisedPriceMinor).toBe('number')});
 it('escapes LIKE wildcards in queries',async()=>{expect((await cat.search({q:'%',page:1,pageSize:10})).total).toBe(0)});
 it('has() and getBySlug() agree',async()=>{expect(await cat.has('iphone-16-128')).toBe(true);expect(await cat.has('nope')).toBe(false);expect((await cat.getBySlug('iphone-16-128'))?.id).toBe('iphone-16-128')});
 it('isolates favorites and alerts per client',async()=>{await store.addFavorite(A,'ipad-10-64');await store.addFavorite(A,'ipad-10-64');expect(await store.listFavorites(A)).toEqual(['ipad-10-64']);expect(await store.listFavorites(B)).toEqual([]);
  const al=await store.createAlert(A,{productId:'ipad-10-64',market:'US',currency:'USD',targetMinor:1000});expect(await store.listAlerts(B)).toEqual([]);
  expect(await store.updateAlert(B,al.id,{targetMinor:5})).toBeNull();expect(await store.deleteAlert(B,al.id)).toBe(false);
  expect((await store.updateAlert(A,al.id,{targetMinor:2000}))?.targetMinor).toBe(2000);expect(await store.deleteAlert(A,al.id)).toBe(true)});
 it('rejects alerts for unknown products (foreign key)',async()=>{await expect(store.createAlert(A,{productId:'nope',market:'US',currency:'USD',targetMinor:1})).rejects.toThrow()})});

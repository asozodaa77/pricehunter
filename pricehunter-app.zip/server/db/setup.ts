// Usage: DATABASE_URL=... npm run db:setup  (schema once, then DEMO seed rows; safe to re-run)
import pg from 'pg';import {setupDatabase} from './seed.ts';
const url=process.env.DATABASE_URL;if(!url){console.error('Set DATABASE_URL first.');process.exit(1)}
const pool=new pg.Pool({connectionString:url});
try{const r=await setupDatabase(pool);console.log(`${r.schemaCreated?'Schema applied. ':'Schema already present. '}Seeded ${r.products} DEMO products (placeholder prices, not real offers).`)}
catch(e){console.error('db:setup failed:',(e as Error).message);process.exitCode=1}finally{await pool.end()}

-- PriceHunter schema (PostgreSQL / Supabase). Money = integer minor units + ISO currency.
create table markets(code char(2) primary key,name text not null,currency char(3) not null check(currency in('USD','CNY','AED','TJS')));
create table products(id text primary key,slug text unique not null,name text not null,brand text not null,category text not null,
 description text,image_urls text[] not null default '{}',specifications jsonb not null default '{}',variant text,storage text,
 condition text not null default 'new' check(condition in('new','refurbished','used')),created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create index on products(category);create index on products(brand);
create table retailer_listings(id uuid primary key default gen_random_uuid(),product_id text not null references products(id) on delete cascade,
 retailer_name text not null,retailer_domain text,market_code char(2) not null references markets(code),
 advertised_price_minor bigint not null check(advertised_price_minor>=0),currency_code char(3) not null,
 product_condition text,availability_status text,product_url text,
 source_type text not null check(source_type in('verified_live','imported','manual','demo','estimate')),
 last_verified_at timestamptz,created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create index on retailer_listings(product_id,market_code);
create table price_history(id uuid primary key default gen_random_uuid(),listing_id uuid not null references retailer_listings(id) on delete cascade,
 price_minor bigint not null check(price_minor>=0),currency_code char(3) not null,recorded_at timestamptz not null,
 source_type text not null check(source_type in('verified_live','imported','manual','demo')));
create index on price_history(listing_id,recorded_at desc);
-- Anonymous ownership via a random client_id (NOT authentication). Add user_id + RLS if auth is added later.
create table favorites(client_id uuid not null,product_id text not null references products(id) on delete cascade,created_at timestamptz not null default now(),primary key(client_id,product_id));
create table price_alerts(id uuid primary key default gen_random_uuid(),client_id uuid not null,product_id text not null references products(id) on delete cascade,
 market_code char(2) not null references markets(code),currency_code char(3) not null,target_minor bigint not null check(target_minor>0),
 status text not null default 'saved_not_monitored' check(status in('saved_not_monitored','active','triggered')),created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create index on price_alerts(client_id);

import type {Pool} from 'pg';import {readFileSync} from 'node:fs';
const read=(p:string)=>readFileSync(new URL(p,import.meta.url),'utf8');
const MARKETS:Record<string,[string,string]>={CN:['China','CNY'],US:['United States','USD'],AE:['United Arab Emirates','AED'],TJ:['Tajikistan','TJS']};
interface Raw{id:string;slug:string;name:string;brand:string;cat:string;storage:string;cond:string;specs:object;L:[string,string,number,string][]}
/** Applies schema.sql if absent, then upserts markets/products and replaces DEMO listings. One transaction + advisory lock: safe to re-run or run concurrently. */
export async function setupDatabase(pool:Pool){
 const c=await pool.connect();
 try{await c.query('begin');await c.query('select pg_advisory_xact_lock(7425001)');
  const created=!(await c.query("select to_regclass('public.markets') as t")).rows[0].t;
  if(created)await c.query(read('./schema.sql'));
  for(const [code,[name,cur]] of Object.entries(MARKETS))await c.query('insert into markets(code,name,currency) values($1,$2,$3) on conflict(code) do update set name=excluded.name,currency=excluded.currency',[code,name,cur]);
  const cat=JSON.parse(read('../data/demo-catalog.json')) as Raw[];
  for(const p of cat){
   await c.query('insert into products(id,slug,name,brand,category,storage,condition,specifications) values($1,$2,$3,$4,$5,$6,$7,$8) on conflict(id) do update set slug=excluded.slug,name=excluded.name,brand=excluded.brand,category=excluded.category,storage=excluded.storage,condition=excluded.condition,specifications=excluded.specifications,updated_at=now()',[p.id,p.slug,p.name,p.brand,p.cat,p.storage,p.cond.toLowerCase(),JSON.stringify(p.specs)]);
   await c.query("delete from retailer_listings where product_id=$1 and source_type='demo'",[p.id]);
   for(const [m,r,minor,cur] of p.L)await c.query("insert into retailer_listings(product_id,retailer_name,market_code,advertised_price_minor,currency_code,product_condition,source_type) values($1,$2,$3,$4,$5,$6,'demo')",[p.id,r,m,minor,cur,p.cond.toLowerCase()])}
  await c.query('commit');return {schemaCreated:created,products:cat.length}
 }catch(e){await c.query('rollback');throw e}finally{c.release()}}

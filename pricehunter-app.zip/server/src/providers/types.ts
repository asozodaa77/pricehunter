export type SourceType='verified_live'|'imported'|'manual'|'demo'|'estimate';
export interface Product{id:string;slug:string;name:string;brand:string;category:string;storage:string;condition:string;specifications:Record<string,string>}
export interface Listing{id:string;productId:string;retailerName:string;marketCode:string;advertisedPriceMinor:number;currencyCode:string;sourceType:SourceType;productUrl:string|null;lastVerifiedAt:string|null}
export interface PricePoint{listingId:string;priceMinor:number;currencyCode:string;recordedAt:string;sourceType:SourceType}
export interface SearchQuery{q?:string;category?:string;brand?:string;market?:string;page:number;pageSize:number}
export interface CatalogProvider{name:string;isDemo:boolean;
 search(q:SearchQuery):Promise<{items:Product[];total:number}>;
 getBySlug(slug:string):Promise<Product|null>;
 has(productId:string):Promise<boolean>;
 listings(productId:string):Promise<Listing[]>;
 history(productId:string):Promise<PricePoint[]>;
 categories():Promise<string[]>}
export interface CurrencyProvider{name:string;getRate(from:string,to:string):Promise<{rate:number;asOf:string|null;source:string}|null>}
export interface AssistantReply{text:string;provider:string;isAi:boolean}
export interface AssistantProvider{name:string;isAi:boolean;reply(message:string,catalog:CatalogProvider):Promise<AssistantReply>}

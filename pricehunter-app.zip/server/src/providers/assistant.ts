import type {AssistantProvider,CatalogProvider} from './types.ts';
/** Rule-based fallback over catalog data. NOT an AI model; replies say so via isAi:false. */
export class RuleBasedAssistant implements AssistantProvider{
 name='rule-based';isAi=false;
 async reply(message:string,catalog:CatalogProvider){
  const {items}=await catalog.search({page:1,pageSize:50});const t=message.toLowerCase();
  const hit=items.filter(p=>t.includes(p.name.toLowerCase()));
  if(!hit.length)return {text:'I could not match a product name in the catalog. Try a full name such as "iPhone 16".',provider:this.name,isAi:false};
  const lines=[];for(const p of hit){const l=await catalog.listings(p.id);
   lines.push(`${p.name} (${p.storage}): ${Object.entries(p.specifications).map(([k,v])=>`${k} ${v}`).join(', ')}. ${l.length} ${catalog.isDemo?'demo ':''}listing(s).`)}
  if(new Set(hit.map(p=>p.storage)).size>1)lines.push('Note: storage variants differ, so prices are not like-for-like.');
  return {text:lines.join('\n'),provider:this.name,isAi:false}}
}

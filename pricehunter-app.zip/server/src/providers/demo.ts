import {readFileSync} from 'node:fs';
import type {CatalogProvider,Product,Listing,SearchQuery} from './types.ts';
interface Raw{id:string;slug:string;name:string;brand:string;cat:string;storage:string;cond:string;specs:Record<string,string>;L:[string,string,number,string][]}
/** Demonstration fixtures only. Prices are placeholders, never verified offers. */
export class DemoCatalogProvider implements CatalogProvider{
 name='demo-fixtures';isDemo=true;private raw:Raw[];
 constructor(path=new URL('../../data/demo-catalog.json',import.meta.url)){this.raw=JSON.parse(readFileSync(path,'utf8'))}
 private p(r:Raw):Product{return {id:r.id,slug:r.slug,name:r.name,brand:r.brand,category:r.cat,storage:r.storage,condition:r.cond.toLowerCase(),specifications:r.specs}}
 async search(q:SearchQuery){const t=q.q?.toLowerCase();
  const m=this.raw.filter(r=>(!t||(r.name+r.brand+r.cat).toLowerCase().includes(t))&&(!q.category||r.cat===q.category)&&(!q.brand||r.brand===q.brand)&&(!q.market||r.L.some(l=>l[0]===q.market)));
  m.sort((a,b)=>a.name.localeCompare(b.name));const s=(q.page-1)*q.pageSize;
  return {items:m.slice(s,s+q.pageSize).map(r=>this.p(r)),total:m.length}}
 async getBySlug(slug:string){const r=this.raw.find(x=>x.slug===slug);return r?this.p(r):null}
 async has(id:string){return this.raw.some(r=>r.id===id)}
 async listings(productId:string):Promise<Listing[]>{const r=this.raw.find(x=>x.id===productId);if(!r)return [];
  return r.L.map((l,i)=>({id:`${r.id}-${i}`,productId:r.id,retailerName:l[1],marketCode:l[0],advertisedPriceMinor:l[2],currencyCode:l[3],sourceType:'demo' as const,productUrl:null,lastVerifiedAt:null}))}
 async history(){return []}
 async categories(){return [...new Set(this.raw.map(r=>r.cat))]}
}

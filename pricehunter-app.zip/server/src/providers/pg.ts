import type {Pool} from 'pg';
import type {CatalogProvider,Product,Listing,SearchQuery,PricePoint,SourceType} from './types.ts';
const toP=(r:any):Product=>({id:r.id,slug:r.slug,name:r.name,brand:r.brand,category:r.category,storage:r.storage??'',condition:r.condition,specifications:r.specifications??{}});
/** Postgres catalog. `isDemo` stays true while the data is the seeded demo fixtures; set CATALOG_IS_DEMO=false only once real provider data is imported. */
export class PgCatalogProvider implements CatalogProvider{
 name='postgres';
 constructor(private pool:Pool,public isDemo=true){}
 async search(q:SearchQuery){const w:string[]=[],a:unknown[]=[];const add=(s:string,v:unknown)=>{a.push(v);w.push(s.replace('?','$'+a.length))};
  if(q.q)add("(name||' '||brand||' '||category) ilike ?",'%'+q.q.replace(/[\\%_]/g,'\\$&')+'%');
  if(q.category)add('category=?',q.category);if(q.brand)add('brand=?',q.brand);
  if(q.market)add('exists(select 1 from retailer_listings l where l.product_id=products.id and l.market_code=?)',q.market);
  const where=w.length?'where '+w.join(' and '):'';
  const t=await this.pool.query(`select count(*)::int as n from products ${where}`,a);
  const r=await this.pool.query(`select * from products ${where} order by name limit $${a.length+1} offset $${a.length+2}`,[...a,q.pageSize,(q.page-1)*q.pageSize]);
  return {items:r.rows.map(toP),total:t.rows[0].n as number}}
 async getBySlug(slug:string){const r=await this.pool.query('select * from products where slug=$1',[slug]);return r.rows[0]?toP(r.rows[0]):null}
 async has(id:string){return (await this.pool.query('select 1 from products where id=$1',[id])).rowCount===1}
 async listings(productId:string):Promise<Listing[]>{const r=await this.pool.query('select * from retailer_listings where product_id=$1 order by market_code,advertised_price_minor',[productId]);
  return r.rows.map(x=>({id:x.id,productId:x.product_id,retailerName:x.retailer_name,marketCode:x.market_code,advertisedPriceMinor:Number(x.advertised_price_minor),currencyCode:x.currency_code,sourceType:x.source_type as SourceType,productUrl:x.product_url,lastVerifiedAt:x.last_verified_at?new Date(x.last_verified_at).toISOString():null}))}
 async history(productId:string):Promise<PricePoint[]>{const r=await this.pool.query('select h.* from price_history h join retailer_listings l on l.id=h.listing_id where l.product_id=$1 order by h.recorded_at',[productId]);
  return r.rows.map(x=>({listingId:x.listing_id,priceMinor:Number(x.price_minor),currencyCode:x.currency_code,recordedAt:new Date(x.recorded_at).toISOString(),sourceType:x.source_type as SourceType}))}
 async categories(){return (await this.pool.query('select distinct category from products order by 1')).rows.map(r=>r.category as string)}
}

import type {CurrencyProvider} from './types.ts';
/** Reads operator-entered rates (MANUAL_RATES={"USD_CNY":7.1}). Returns null when no rate is configured; never guesses. */
export class ManualCurrencyProvider implements CurrencyProvider{
 name='manual-server-config';
 rates:Record<string,number>;asOf:string|null;
 constructor(rates:Record<string,number>,asOf:string|null){this.rates=rates;this.asOf=asOf}
 async getRate(from:string,to:string){if(from===to)return {rate:1,asOf:null,source:'identity'};
  const d=this.rates[`${from}_${to}`],i=this.rates[`${to}_${from}`];
  const rate=d>0?d:i>0?1/i:null;return rate?{rate,asOf:this.asOf,source:this.name}:null}
}

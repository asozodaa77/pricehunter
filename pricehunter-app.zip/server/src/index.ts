import express from 'express';import {existsSync} from 'node:fs';import {fileURLToPath} from 'node:url';import pg from 'pg';
import {createApp} from './app.ts';import {DemoCatalogProvider} from './providers/demo.ts';import {PgCatalogProvider} from './providers/pg.ts';
import {ManualCurrencyProvider} from './providers/currency.ts';import {RuleBasedAssistant} from './providers/assistant.ts';import {MemoryStore} from './store.ts';import {PgStore} from './pgStore.ts';
const pool=process.env.DATABASE_URL?new pg.Pool({connectionString:process.env.DATABASE_URL,max:10,connectionTimeoutMillis:5000}):null;
pool?.on('error',e=>console.error('Postgres pool error:',e.message));
if(pool){try{await pool.query('select 1')}catch{console.error('Cannot connect to Postgres. Check DATABASE_URL (hosted databases usually need ?sslmode=require).');process.exit(1)}}
let rates:Record<string,number>={};
try{rates=JSON.parse(process.env.MANUAL_RATES||'{}')}catch{console.error('MANUAL_RATES must be valid JSON, e.g. {"USD_AED":3.6725}');process.exit(1)}
const app=createApp({catalog:pool?new PgCatalogProvider(pool,process.env.CATALOG_IS_DEMO!=='false'):new DemoCatalogProvider(),
 currency:new ManualCurrencyProvider(rates,process.env.MANUAL_RATES_DATE||null),assistant:new RuleBasedAssistant(),store:pool?new PgStore(pool):new MemoryStore(),origin:process.env.ALLOWED_ORIGIN});
if(process.env.TRUST_PROXY)app.set('trust proxy',Number(process.env.TRUST_PROXY)||process.env.TRUST_PROXY); // needed behind a reverse proxy so rate limits see real client IPs
const dist=fileURLToPath(new URL('../../dist/',import.meta.url));
if(existsSync(dist+'index.html')){app.use(express.static(dist));app.get(/^\/(?!api\/).*/,(_q,s)=>{s.sendFile(dist+'index.html')})} // single-container deploy: serve the built frontend
const port=Number(process.env.PORT||8787);
const srv=app.listen(port,()=>console.log(`PriceHunter on :${port} (${pool?'Postgres catalog':'demo-fixture catalog'}, ${pool?'Postgres':'in-memory'} user store)`));
for(const sig of ['SIGTERM','SIGINT'])process.on(sig,()=>{srv.close(()=>{pool?.end().finally(()=>process.exit(0))})});

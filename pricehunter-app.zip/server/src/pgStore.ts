import type {Pool} from 'pg';
import type {UserStore,Alert,NewAlert} from './store.ts';
type Row={id:string;product_id:string;market_code:string;currency_code:string;target_minor:string;status:'saved_not_monitored';created_at:Date};
const toAlert=(r:Row):Alert=>({id:r.id,productId:r.product_id,market:r.market_code,currency:r.currency_code,targetMinor:Number(r.target_minor),status:r.status,createdAt:r.created_at.toISOString()});
/** Postgres-backed store. All queries are parameterized. client_id scopes rows but is NOT authentication. */
export class PgStore implements UserStore{
 constructor(private pool:Pool){}
 async listFavorites(c:string){return (await this.pool.query('select product_id from favorites where client_id=$1 order by created_at',[c])).rows.map(r=>r.product_id as string)}
 async addFavorite(c:string,p:string){await this.pool.query('insert into favorites(client_id,product_id) values($1,$2) on conflict do nothing',[c,p])}
 async removeFavorite(c:string,p:string){await this.pool.query('delete from favorites where client_id=$1 and product_id=$2',[c,p])}
 async listAlerts(c:string){return (await this.pool.query('select * from price_alerts where client_id=$1 order by created_at',[c])).rows.map(toAlert)}
 async createAlert(c:string,a:NewAlert){const r=await this.pool.query('insert into price_alerts(client_id,product_id,market_code,currency_code,target_minor) values($1,$2,$3,$4,$5) returning *',[c,a.productId,a.market,a.currency,a.targetMinor]);return toAlert(r.rows[0])}
 async updateAlert(c:string,id:string,p:Partial<NewAlert>){const r=await this.pool.query('update price_alerts set market_code=coalesce($3,market_code),currency_code=coalesce($4,currency_code),target_minor=coalesce($5,target_minor),updated_at=now() where client_id=$1 and id=$2 returning *',[c,id,p.market??null,p.currency??null,p.targetMinor??null]);return r.rows[0]?toAlert(r.rows[0]):null}
 async deleteAlert(c:string,id:string){return (await this.pool.query('delete from price_alerts where client_id=$1 and id=$2',[c,id])).rowCount===1}
}

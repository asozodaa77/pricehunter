export interface EstimateInput{price:number;from:string;to:string;rate?:number;shipping:number;insurance:number;customs:number;other:number}
const minor=(n:number)=>Math.round(n*100);
/** Integer minor-unit arithmetic. Extra charges are in the target currency. Never invents a rate. */
export function estimate(i:EstimateInput){
 if(i.from!==i.to&&!i.rate)return {ok:false as const,error:'exchange_rate_required'};
 const rate=i.from===i.to?1:(i.rate as number);
 const original=minor(i.price),converted=Math.round(original*rate);
 const b={shipping:minor(i.shipping),insurance:minor(i.insurance),customs:minor(i.customs),other:minor(i.other)};
 const total=converted+b.shipping+b.insurance+b.customs+b.other;
 if(!Number.isSafeInteger(total))return {ok:false as const,error:'amount_too_large'};
 return {ok:true as const,isEstimate:true,rate,rateSource:i.from===i.to?'none needed':'client-supplied (manual)',
  originalMinor:original,from:i.from,to:i.to,convertedMinor:converted,breakdownMinor:b,totalMinor:total};
}

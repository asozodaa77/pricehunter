import {randomUUID} from 'node:crypto';
export interface Alert{id:string;productId:string;market:string;currency:string;targetMinor:number;status:'saved_not_monitored';createdAt:string}
export type NewAlert=Omit<Alert,'id'|'status'|'createdAt'>;
export interface UserStore{
 listFavorites(c:string):Promise<string[]>;addFavorite(c:string,p:string):Promise<void>;removeFavorite(c:string,p:string):Promise<void>;
 listAlerts(c:string):Promise<Alert[]>;createAlert(c:string,a:NewAlert):Promise<Alert>;
 updateAlert(c:string,id:string,p:Partial<NewAlert>):Promise<Alert|null>;deleteAlert(c:string,id:string):Promise<boolean>}
/** In-memory store: data is lost on restart. A Postgres adapter for server/db/schema.sql is still to be written. */
export class MemoryStore implements UserStore{
 private f=new Map<string,Set<string>>();private a=new Map<string,Alert[]>();
 async listFavorites(c:string){return [...(this.f.get(c)??[])]}
 async addFavorite(c:string,p:string){(this.f.get(c)??this.f.set(c,new Set()).get(c)!).add(p)}
 async removeFavorite(c:string,p:string){this.f.get(c)?.delete(p)}
 async listAlerts(c:string){return this.a.get(c)??[]}
 async createAlert(c:string,n:NewAlert){const al:Alert={...n,id:randomUUID(),status:'saved_not_monitored',createdAt:new Date().toISOString()};
  this.a.set(c,[...(this.a.get(c)??[]),al]);return al}
 async updateAlert(c:string,id:string,p:Partial<NewAlert>){const x=(this.a.get(c)??[]).find(y=>y.id===id);if(!x)return null;Object.assign(x,p);return x}
 async deleteAlert(c:string,id:string){const l=this.a.get(c)??[];const n=l.filter(y=>y.id!==id);this.a.set(c,n);return n.length!==l.length}
}

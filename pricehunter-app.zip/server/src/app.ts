import express from 'express';import type {Request,Response,NextFunction} from 'express';
import cors from 'cors';import helmet from 'helmet';import rateLimit from 'express-rate-limit';import {ZodError} from 'zod';
import * as v from './validators.ts';import {estimate} from './calc.ts';
import type {CatalogProvider,CurrencyProvider,AssistantProvider} from './providers/types.ts';import type {UserStore} from './store.ts';
export interface Deps{catalog:CatalogProvider;currency:CurrencyProvider;assistant:AssistantProvider;store:UserStore;origin?:string}
const MARKET_INFO={CN:['China','CNY'],US:['United States','USD'],AE:['United Arab Emirates','AED'],TJ:['Tajikistan','TJS']} as const;
const wrap=(f:(q:Request,s:Response)=>Promise<unknown>)=>(q:Request,s:Response,n:NextFunction)=>{f(q,s).catch(n)};
export function createApp(d:Deps){
 const app=express();app.disable('x-powered-by');app.use(helmet({contentSecurityPolicy:{useDefaults:true,directives:{'upgrade-insecure-requests':null}}}));app.use(cors({origin:d.origin??false}));app.use(express.json({limit:'20kb'}));
 app.use('/api',rateLimit({windowMs:60000,limit:120,standardHeaders:true,legacyHeaders:false}));
 app.use('/api/assistant',rateLimit({windowMs:60000,limit:20}));
 const meta={dataMode:d.catalog.isDemo?'demo':'provider',provider:d.catalog.name};
 const cid=(q:Request)=>v.clientId.parse(q.header('x-client-id'));
 const notFound=(s:Response,w:string)=>s.status(404).json({error:'not_found',message:`${w} not found`});
 app.get('/api/health',(_q,s)=>{s.json({ok:true,...meta})});
 app.get('/api/products',wrap(async(q,s)=>{const r=await d.catalog.search(v.listQuery.parse(q.query));
  const items=await Promise.all(r.items.map(async p=>({...p,listings:await d.catalog.listings(p.id)})));s.json({items,total:r.total,...meta})}));
 app.get('/api/search',wrap(async(q,s)=>{const r=await d.catalog.search(v.listQuery.parse(q.query));s.json({...r,...meta})}));
 app.get('/api/categories',wrap(async(_q,s)=>{s.json({items:await d.catalog.categories()})}));
 app.get('/api/markets',(_q,s)=>{s.json({items:Object.entries(MARKET_INFO).map(([code,x])=>({code,name:x[0],currency:x[1]})),...meta})});
 app.get('/api/products/:slug',wrap(async(q,s)=>{const p=await d.catalog.getBySlug(q.params.slug);p?s.json({item:p,...meta}):notFound(s,'Product')}));
 app.get('/api/products/:slug/listings',wrap(async(q,s)=>{const p=await d.catalog.getBySlug(q.params.slug);if(!p)return notFound(s,'Product');s.json({items:await d.catalog.listings(p.id),...meta})}));
 app.get('/api/products/:slug/history',wrap(async(q,s)=>{const p=await d.catalog.getBySlug(q.params.slug);if(!p)return notFound(s,'Product');
  const items=await d.catalog.history(p.id);s.json({items,note:items.length?undefined:'No verified price history is available from the configured provider.'})}));
 app.get('/api/rates',wrap(async(q,s)=>{const f=v.currency.parse(q.query.from),t=v.currency.parse(q.query.to);const r=await d.currency.getRate(f,t);
  r?s.json(r):s.status(404).json({error:'rate_unavailable',message:'No exchange rate is configured. Enter one manually.'})}));
 app.post('/api/calculator/estimate',wrap(async(q,s)=>{const r=estimate(v.estimateBody.parse(q.body));r.ok?s.json(r):s.status(422).json({error:r.error,message:r.error==='exchange_rate_required'?'An exchange rate is required when currencies differ.':'Amount is too large to estimate.'})}));
 app.get('/api/favorites',wrap(async(q,s)=>{s.json({items:await d.store.listFavorites(cid(q))})}));
 app.post('/api/favorites',wrap(async(q,s)=>{const b=v.favBody.parse(q.body);const c=cid(q);
  if(!(await d.catalog.has(b.productId)))return notFound(s,'Product');
  await d.store.addFavorite(c,b.productId);s.status(201).json({productId:b.productId})}));
 app.delete('/api/favorites/:productId',wrap(async(q,s)=>{await d.store.removeFavorite(cid(q),q.params.productId);s.status(204).end()}));
 app.get('/api/alerts',wrap(async(q,s)=>{s.json({items:await d.store.listAlerts(cid(q)),note:'Alerts are stored but no price monitoring or notification service is configured.'})}));
 app.post('/api/alerts',wrap(async(q,s)=>{const b=v.alertBody.parse(q.body);if(!(await d.catalog.has(b.productId)))return notFound(s,'Product');s.status(201).json({item:await d.store.createAlert(cid(q),b)})}));
 app.patch('/api/alerts/:id',wrap(async(q,s)=>{const r=await d.store.updateAlert(cid(q),q.params.id,v.alertPatch.parse(q.body));r?s.json({item:r}):notFound(s,'Alert')}));
 app.delete('/api/alerts/:id',wrap(async(q,s)=>{(await d.store.deleteAlert(cid(q),q.params.id))?s.status(204).end():notFound(s,'Alert')}));
 app.post('/api/assistant',wrap(async(q,s)=>{s.json(await d.assistant.reply(v.assistantBody.parse(q.body).message,d.catalog))}));
 app.use('/api',(_q,s)=>{s.status(404).json({error:'not_found',message:'Unknown endpoint'})});
 app.use((e:unknown,_q:Request,s:Response,_n:NextFunction)=>{
  if(e instanceof ZodError)return void s.status(400).json({error:'validation_error',issues:e.issues.map(i=>({path:i.path.join('.'),message:i.message}))});
  const t=(e as {type?:string}|null)?.type;
  if(t==='entity.parse.failed')return void s.status(400).json({error:'invalid_json',message:'Request body is not valid JSON.'});
  if(t==='entity.too.large')return void s.status(413).json({error:'payload_too_large',message:'Request body is too large.'});
  console.error('Unhandled error');s.status(500).json({error:'internal_error',message:'Something went wrong.'})});
 return app}

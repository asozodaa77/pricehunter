import {z} from 'zod';
export const CURRENCIES=['USD','CNY','AED','TJS'] as const;
export const MARKETS=['CN','US','AE','TJ'] as const;
export const currency=z.enum(CURRENCIES);
export const market=z.enum(MARKETS);
const amount=z.number().finite().min(0).max(1e9);
export const clientId=z.string().uuid();
export const estimateBody=z.object({price:amount,from:currency,to:currency,rate:z.number().positive().max(1e6).finite().optional(),
 shipping:amount.default(0),insurance:amount.default(0),customs:amount.default(0),other:amount.default(0)});
export const listQuery=z.object({q:z.string().trim().max(80).optional(),category:z.string().max(40).optional(),brand:z.string().max(40).optional(),
 market:market.optional(),page:z.coerce.number().int().min(1).default(1),pageSize:z.coerce.number().int().min(1).max(50).default(20)});
export const favBody=z.object({productId:z.string().min(1).max(80)});
export const alertBody=z.object({productId:z.string().min(1).max(80),market,currency,targetMinor:z.number().int().positive().max(1e12)});
export const alertPatch=alertBody.omit({productId:true}).partial().refine(o=>Object.keys(o).length>0,'empty patch');
export const assistantBody=z.object({message:z.string().trim().min(1).max(500)});
